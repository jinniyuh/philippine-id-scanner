<?php
session_start();
include 'includes/conn.php';

// Fetch user information
if (isset($_SESSION["user_id"])) {
    $userId = $_SESSION["user_id"];
    $queryUser = "SELECT * FROM users WHERE user_id = '$userId'";
    $resultUser = mysqli_query($conn, $queryUser);
    if ($resultUser && mysqli_num_rows($resultUser) > 0) {
        $user = mysqli_fetch_assoc($resultUser);
        $staffName = isset($user['name']) ? $user['name'] : 'Staff Name';
    } else {
        $staffName = "Staff Name";
    }
} else {
    $staffName = "Staff Name";
}

// Count total items
$queryTotalItems = "SELECT COUNT(*) as total FROM pharmaceuticals";
$resultTotalItems = mysqli_query($conn, $queryTotalItems);
$totalItems = ''; // Default value
if ($resultTotalItems && mysqli_num_rows($resultTotalItems) > 0) {
    $row = mysqli_fetch_assoc($resultTotalItems);
    $totalItems = $row['total'];
}

// Count expiring soon
$today = date('Y-m-d');
$nextWeek = date('Y-m-d', strtotime('+7 days'));
$queryExpiringSoon = "SELECT COUNT(*) as expiring FROM pharmaceuticals WHERE expiry_date BETWEEN '$today' AND '$nextWeek'";
$resultExpiringSoon = mysqli_query($conn, $queryExpiringSoon);
$expiringSoon = ''; // Default value
if ($resultExpiringSoon && mysqli_num_rows($resultExpiringSoon) > 0) {
    $row = mysqli_fetch_assoc($resultExpiringSoon);
    $expiringSoon = $row['expiring'];
}

// Count low stock
$queryLowStock = "SELECT COUNT(*) as low FROM pharmaceuticals WHERE stock < 20";
$resultLowStock = mysqli_query($conn, $queryLowStock);
$lowStock = 15; // Default value
if ($resultLowStock && mysqli_num_rows($resultLowStock) > 0) {
    $row = mysqli_fetch_assoc($resultLowStock);
    $lowStock = $row['low'];
}

// Count categories
$queryCategories = "SELECT COUNT(DISTINCT category) as categories FROM pharmaceuticals";
$resultCategories = mysqli_query($conn, $queryCategories);
$categories = 30; // Default value
if ($resultCategories && mysqli_num_rows($resultCategories) > 0) {
    $row = mysqli_fetch_assoc($resultCategories);
    $categories = $row['categories'];
}

// Get pharmaceuticals
$queryPharmaceuticals = "SELECT * FROM pharmaceuticals ORDER BY pharma_id LIMIT 10";
$resultPharmaceuticals = mysqli_query($conn, $queryPharmaceuticals);
$pharmaceuticals = [];

if ($resultPharmaceuticals && mysqli_num_rows($resultPharmaceuticals) > 0) {
    while ($row = mysqli_fetch_assoc($resultPharmaceuticals)) {
        $pharmaceuticals[] = $row;
    }
}

// After the existing queries, add these new queries to get alert data

// Get expiring pharmaceuticals
$queryExpiringItems = "SELECT name, DATEDIFF(expiry_date, CURDATE()) as days_left FROM pharmaceuticals 
  WHERE expiry_date BETWEEN '$today' AND '$nextWeek' 
  ORDER BY expiry_date ASC";
$resultExpiringItems = mysqli_query($conn, $queryExpiringItems);
$expiringItems = [];
if ($resultExpiringItems && mysqli_num_rows($resultExpiringItems) > 0) {
    while ($row = mysqli_fetch_assoc($resultExpiringItems)) {
        $expiringItems[] = $row;
    }
}

// Get low stock items
$queryLowStockItems = "SELECT name FROM pharmaceuticals WHERE stock < 20 ORDER BY stock ASC LIMIT 5";
$resultLowStockItems = mysqli_query($conn, $queryLowStockItems);
$lowStockItems = [];
if ($resultLowStockItems && mysqli_num_rows($resultLowStockItems) > 0) {
    while ($row = mysqli_fetch_assoc($resultLowStockItems)) {
        $lowStockItems[] = $row;
    }
}

// Count vaccines that need restocking
$queryVaccinesLow = "SELECT COUNT(*) as count FROM pharmaceuticals 
WHERE category = 'Vaccine' AND stock < 20";
$resultVaccinesLow = mysqli_query($conn, $queryVaccinesLow);
$vaccinesLowCount = 0;
if ($resultVaccinesLow && mysqli_num_rows($resultVaccinesLow) > 0) {
    $row = mysqli_fetch_assoc($resultVaccinesLow);
    $vaccinesLowCount = $row['count'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Pharmaceuticals Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    /* Main container which holds the sidebar and main content */
    body {
      background-color: #7B8EF3;
      font-family: Arial, sans-serif;
    }
    .container-fluid {
      padding-left: 0;
      padding-right: 0;
      overflow-x: hidden;
    }
    .wrapper {
      display: flex;
      align-items: flex-start;
    }
    /* Main content styling */
    .main-content {
      background: white;
      margin: 20px;
      margin-left: 312px;
      padding: 0 25px 25px 25px;
      border-radius: 10px;
      min-height: 600px;
      height: calc(100vh - 40px);
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
    }
    /* Minimize and style scrollbar for main-content */
    .main-content::-webkit-scrollbar {
      width: 8px;
      background: transparent;
    }
    .main-content::-webkit-scrollbar-thumb {
      background: #bdbdbd;
      border-radius: 8px;
    }
    .main-content::-webkit-scrollbar-track {
      background: transparent;
    }
    .main-content {
      scrollbar-width: thin;
      scrollbar-color: #bdbdbd transparent;
    }
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: calc(100% + 50px);
      min-height: 80px;
      margin: 0 -25px 0 -25px;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      padding: 10px 25px 0 25px;  
      position: sticky;
      top: 0;
      background: white;
      z-index: 10;
    }
    .page-title h2 {
      margin: 0;
      font-weight: bold;
    }
    .staff-info {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .stats-box {
      background: white;
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      height: 150px;
      width: 100%;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    .stats-box h5 {
        color: #666;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
    }
    
    .stats-box h3 {
        font-size: 2.5rem;
        font-weight: bold;
        margin: 10px 0;
    }
    .stats-box .display-4 {
        font-size: 3rem;
        font-weight: bold;
        margin: 10px 0;
    }
    .alert-box {
      background-color: #fff3cd;
      border-left: 4px solid #ffc107;
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 4px;
    }
    .alert-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-weight: bold;
      margin-bottom: 10px;
    }
    .alert-icon {
      color: #ffc107;
    }
    .alert-list {
      margin: 0;
      padding-left: 25px;
    }
    .alert-list li {
      margin-bottom: 5px;
    }
    .search-container {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
    }
    .search-box {
      flex-grow: 1;
      position: relative;
    }
    .search-input {
      width: 100%;
      padding: 8px 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    .search-button {
      position: absolute;
      right: 5px;
      top: 5px;
      background-color: #8B9FF7;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 5px 10px;
      cursor: pointer;
    }
    .filter-dropdown {
      padding: 8px 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      background-color: white;
    }
    .pharmaceuticals-table {
      width: 100%;
      border-collapse: collapse;
    }
    .pharmaceuticals-table th {
      background-color: #f5f5f5;
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    .pharmaceuticals-table td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }
    .low-stock {
      background-color: #28a745;
      color: white;
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 12px;
    }
  </style>
</head>
<body>
  <div class="container-fluid">
    <!-- Sidebar Section -->
    <div class="wrapper">
      <div class="sidebar">
        <?php include 'includes/staff_sidebar.php'; ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
      <!-- Page Header -->
      <div class="page-header">
        <div class="page-title">
<h2>Pharmaceuticals Management</h2></div>
        <div class="staff-info">
<div class="d-flex align-items-center gap-3">
  <i class="fas fa-user-circle"></i>
</div>
<div><?php echo htmlspecialchars($staffName); ?></div>
        </div>
      </div>
      
      <!-- Stats Cards -->
      <div class="row g-3 mb-4">
        <div class="col-md-3">
<div class="stats-box d-flex flex-column align-items-center justify-content-center ">
        <h5><i class="fas fa-capsules me-2"></i>Total Items</h5>
        <h3><?php echo $totalItems; ?></h3>
</div>
        </div>
        <div class="col-md-3">
<div class="stats-box d-flex flex-column align-items-center justify-content-center">
        <h5><i class="fas fa-hourglass-half me-2"></i>Expiring Soon</h5>
        <h3><?php echo $expiringSoon; ?></h3>
</div>
        </div>
        <div class="col-md-3">
<div class="stats-box d-flex flex-column align-items-center justify-content-center">
        <h5><i class="fas fa-exclamation-circle me-2"></i>Low Stock</h5>
        <h3><?php echo $lowStock; ?></h3>
</div>
        </div>
        <div class="col-md-3">
<div class="stats-box d-flex flex-column align-items-center justify-content-center">
        <h5><i class="fas fa-list-alt me-2"></i>Categories</h5>
        <h3><?php echo $categories; ?></h3>
</div>
        </div>
      </div>
      
      <!-- Alert Box -->
      <div class="alert-box">
        <div class="alert-title">
<i class="fas fa-exclamation-triangle alert-icon"></i>
Attention Required
        </div>
        <ul class="alert-list">
<?php if (!empty($expiringItems)): ?>
  <?php foreach($expiringItems as $item): ?>
    <li><?php echo htmlspecialchars($item['name']); ?> expires in <?php echo $item['days_left']; ?> days</li>
  <?php endforeach; ?>
<?php endif; ?>

<?php if ($expiringSoon > 0): ?>
  <li><?php echo $expiringSoon; ?> items expiring within 7 days</li>
<?php endif; ?>

<?php if ($vaccinesLowCount > 0): ?>
  <li><?php echo $vaccinesLowCount; ?> vaccines need restocking</li>
<?php endif; ?>

<?php if (empty($expiringItems) && $expiringSoon == 0 && $vaccinesLowCount == 0): ?>
  <li>No urgent attention required at this time</li>
<?php endif; ?>
        </ul>
      </div>
      
      <!-- Search and Filters -->
      <div class="search-container">
        <div class="search-box">
<input type="text" class="search-input" placeholder="Search pharmaceuticals...">
<button class="search-button">
  <i class="fas fa-search"></i>
</button>
        </div>
        <select class="filter-dropdown" style="max-width: 150px;">
<option>All Category</option>
<option>Vitamins</option>
<option>Vaccines</option>
<option>Antibiotics</option>
        </select>
        <select class="filter-dropdown" style="max-width: 150px;">
<option>All Stock Level</option>
<option>Low Stock</option>
<option>Sufficient</option>
<option>Overstocked</option>
        </select>
        <select class="filter-dropdown" style="max-width: 150px;">
<option>All Expiry Dates</option>
<option>Expiring Soon</option>
<option>Expired</option>
<option>Valid</option>
        </select>
      </div>
      
      <!-- Pharmaceuticals Table -->
      <table class="pharmaceuticals-table">
        <thead>
<tr>
  <th>Name</th>
  <th>Category</th>
  <th>Stock Level</th>
  <th>Expiration Date</th>
  <th>Last Updated</th>
</tr>
        </thead>
        <tbody>
<?php foreach ($pharmaceuticals as $item): ?>
  <tr>
    <td><?php echo htmlspecialchars($item['name']); ?></td>
    <td><?php echo htmlspecialchars($item['category']); ?></td>
    <td>
      <span class="low-stock" style="background-color: #dc3545;">
        <?php echo htmlspecialchars($item['stock']); ?>
      </span>
    </td>
    <td><?php echo date('Y-m-d', strtotime($item['expiry_date'])); ?></td>
    <td><?php echo date('Y-m-d', strtotime($item['updated_at'])); ?></td>
  </tr>
<?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('.search-input');
    const searchButton = document.querySelector('.search-button');
    const categoryFilter = document.querySelectorAll('.filter-dropdown')[0];
    const stockFilter = document.querySelectorAll('.filter-dropdown')[1];
    const expiryFilter = document.querySelectorAll('.filter-dropdown')[2];
    const tableRows = document.querySelectorAll('.pharmaceuticals-table tbody tr');

    // Search function
    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase();
        const categoryValue = categoryFilter.value;
        const stockValue = stockFilter.value;
        const expiryValue = expiryFilter.value;

        tableRows.forEach(row => {
            const id = row.cells[0].textContent.toLowerCase();
            const name = row.cells[1].textContent.toLowerCase();
            const category = row.cells[2].textContent.toLowerCase();
            const stock = parseInt(row.cells[3].textContent.trim());
            const expiryDate = new Date(row.cells[4].textContent);
            const today = new Date();
            const daysUntilExpiry = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));

            // Check search term match
            const matchesSearch = searchTerm === '' || 
                                id.includes(searchTerm) || 
                                name.includes(searchTerm) || 
                                category.includes(searchTerm);

            // Check category filter
            const matchesCategory = categoryValue === 'All Category' || 
                                  category.includes(categoryValue.toLowerCase());

            // Check stock level filter
            let matchesStock = true;
            if (stockValue === 'Low Stock') {
                matchesStock = stock < 20;
            } else if (stockValue === 'Sufficient') {
                matchesStock = stock >= 20 && stock <= 100;
            } else if (stockValue === 'Overstocked') {
                matchesStock = stock > 100;
            }

            // Check expiry filter
            let matchesExpiry = true;
            if (expiryValue === 'Expiring Soon') {
                matchesExpiry = daysUntilExpiry <= 7 && daysUntilExpiry >= 0;
            } else if (expiryValue === 'Expired') {
                matchesExpiry = daysUntilExpiry < 0;
            } else if (expiryValue === 'Valid') {
                matchesExpiry = daysUntilExpiry > 7;
            }

            // Show/hide row based on all filters
            if (matchesSearch && matchesCategory && matchesStock && matchesExpiry) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // Event listeners
    searchButton.addEventListener('click', performSearch);
    searchInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    searchInput.addEventListener('input', performSearch);
    categoryFilter.addEventListener('change', performSearch);
    stockFilter.addEventListener('change', performSearch);
    expiryFilter.addEventListener('change', performSearch);
});
</script>

</body>
</html>

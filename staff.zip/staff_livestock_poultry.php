<?php
session_start();
include 'includes/conn.php';

// Fetch user information
if (isset($_SESSION["user_id"])) {
    $userId = $_SESSION["user_id"];
    $queryUser = "SELECT * FROM users WHERE user_id = '$userId'";
    $resultUser = mysqli_query($conn, $queryUser);
    if ($resultUser && mysqli_num_rows($resultUser) > 0) {
        $user = mysqli_fetch_assoc($resultUser);
        $staffName = isset($user['name']) ? $user['name'] : 'Staff Name';
    } else {
        $staffName = "Staff Name";
    }
} else {
    $staffName = "Staff Name";
}

// Count total livestock
$queryTotalLivestock = "SELECT SUM(quantity) as total FROM livestock_poultry WHERE animal_type = 'Livestock'";
$resultTotalLivestock = mysqli_query($conn, $queryTotalLivestock);
$totalLivestock = 0; // Default value
if ($resultTotalLivestock && mysqli_num_rows($resultTotalLivestock) > 0) {
    $row = mysqli_fetch_assoc($resultTotalLivestock);
    $totalLivestock = $row['total'] ?? 0;
}

// Count total poultry
$queryTotalPoultry = "SELECT SUM(quantity) as total FROM livestock_poultry WHERE animal_type = 'Poultry'";
$resultTotalPoultry = mysqli_query($conn, $queryTotalPoultry);
$totalPoultry = 0; // Default value
if ($resultTotalPoultry && mysqli_num_rows($resultTotalPoultry) > 0) {
    $row = mysqli_fetch_assoc($resultTotalPoultry);
    $totalPoultry = $row['total'] ?? 0;
}

// Get livestock data
$queryLivestock = "SELECT lp.*, c.full_name as client_name FROM livestock_poultry lp 
                  LEFT JOIN clients c ON lp.client_id = c.client_id 
                  WHERE lp.animal_type = 'Livestock' 
                  ORDER BY lp.animal_id";
$resultLivestock = mysqli_query($conn, $queryLivestock);
$livestock = [];

if ($resultLivestock && mysqli_num_rows($resultLivestock) > 0) {
    while ($row = mysqli_fetch_assoc($resultLivestock)) {
        $livestock[] = $row;
    }
}
// Get poultry data
$queryPoultry = "SELECT lp.*, c.full_name as client_name FROM livestock_poultry lp 
                LEFT JOIN clients c ON lp.client_id = c.client_id 
                WHERE lp.animal_type = 'Poultry' 
                ORDER BY lp.animal_id";
$resultPoultry = mysqli_query($conn, $queryPoultry);
$poultry = [];

if ($resultPoultry && mysqli_num_rows($resultPoultry) > 0) {
    while ($row = mysqli_fetch_assoc($resultPoultry)) {
        $poultry[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Livestock & Poultry Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            body {
                background-color: #7B8EF3;
                font-family: Arial, sans-serif;
            }
            
            .container-fluid {
                padding-left: 0;
                padding-right: 0;
                overflow-x: hidden;
            }
            
            /* Main content white box styling */
            .white-box {
                background: white;
                margin: 20px;
                margin-left: 312px;
                padding: 0 25px 25px 25px;
                border-radius: 10px;
                min-height: 600px;
                height: calc(100vh - 40px);
                overflow-y: auto;
                flex: 1;
                display: flex;
                flex-direction: column;
            }
            /* Stats boxes styling */
            .stats-box {
                background: white;
                border-radius: 10px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                height: 150px;
                width: 100%;
                text-align: center;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
            }
            
            .stats-box h5 {
                color: #666;
                margin-bottom: 10px;
                display: flex;
                align-items: center;
            }
            
            .stats-box h3 {
                font-size: 2.5rem;
                font-weight: bold;
                margin: 10px 0;
            }
            .stats-box .display-4 {
                font-size: 3rem;
                font-weight: bold;
                margin: 10px 0;
            }
            /* Search bar styling */
            .input-group .form-control {
                border-radius: 20px 0 0 20px;
                padding: 10px 15px;
            }
            
            .input-group .btn {
                border-radius: 0 20px 20px 0;
                background-color: #8B9FF7;
                border-color: #8B9FF7;
            }
            
            /* Alert styling */
            .alert {
                border-radius: 10px;
                margin-bottom: 25px;
            }
            
            /* Fix notification badge positioning */
            .position-relative {
                display: inline-block;
            }
            
            .position-absolute {
                top: -10px !important;
                right: -10px !important;
            }
            
            .wrapper {
                display: flex;
                align-items: flex-start;
            }
            /* Add hover effect for table rows */
            .table tbody tr:hover {
                background-color: #f8f9fa;
                cursor: pointer;
            }
            .updates-section {
                background: #FFF3CD;
                border-radius: 10px;
                padding: 20px;
            }
            
            .updates-section li {
                margin-bottom: 10px;
            }
            
            .updates-section i {
                margin-right: 10px;
            }
            
            .pharmaceuticals-table {
                background: white;
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .table th, .table td {
                padding: 12px;
                border-bottom: 1px solid #dee2e6;
            }
            
            .badge {
                padding: 5px 10px;
                margin-right: 5px;
            }
            .badge.active {
                background-color: #28a745;
                color: white;
            }
            
            /* Header inside the white box */
            .white-box .dashboard-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                width: calc(100% + 50px);
                min-height: 80px;
                margin: 0 -25px 0 -25px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                position: sticky;
                top: 0;
                background: white;
                z-index: 10;
                padding: 10px 25px 0 25px;
            }
            
            .white-box .dashboard-header h2 {
                margin: 0;
                font-weight: bold;
            }
            
            .white-box .alert {
                margin-bottom: 25px;
                border-radius: 10px;
            }

            /* Minimize and style scrollbar for white-box */
            .white-box::-webkit-scrollbar {
                width: 8px;
                background: transparent;
            }
            .white-box::-webkit-scrollbar-thumb {
                background: #bdbdbd;
                border-radius: 8px;
            }
            .white-box::-webkit-scrollbar-track {
                background: transparent;
            }
            .white-box {
                scrollbar-width: thin;
                scrollbar-color: #bdbdbd transparent;
            }

            .tab-content {
                display: none !important;
            }
            .tab-content.active {
                display: block !important;
            }

            .tab-buttons {
                display: flex;
                justify-content: center;
                gap: 10px;
                margin-bottom: 15px;
            }
            .tab-button {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 4px;
                padding: 7px 22px;
                cursor: pointer;
                font-weight: 500;
                color: #333;
                transition: background 0.2s, color 0.2s;
            }
            .tab-button.active {
                background-color: #8B9FF7;
                color: #fff;
                border-color: #8B9FF7;
            }
            .status-healthy {
              background-color: #28a745;
              color: white;
              padding: 3px 8px;
              border-radius: 12px;
              font-size: 12px;
            }
            .status-check {
              background-color: #ffc107;
              color: white;
              padding: 3px 8px;
              border-radius: 12px;
              font-size: 12px;
            }
        </style>
</head>
<body>
  <div class="container-fluid">
    <div class="wrapper">
      <!-- Sidebar Section -->
      <div class="sidebar">
        <?php include 'includes/staff_sidebar.php'; ?>
      </div>
      <!-- Main Content -->
      <div class="white-box">
        <div class="dashboard-header d-flex justify-content-between align-items-center">
          <h2>Livestock & Poultry Management</h2>
          <div class="d-flex align-items-center gap-3">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($staffName); ?></span>
          </div>
        </div>
        <!-- Stats -->
        <?php
        // Count Disseminated and Owned for Livestock
        $livestockDisseminated = 0;
        $livestockOwned = 0;
        foreach ($livestock as $animal) {
          if (strtolower($animal['source']) === 'disseminated') $livestockDisseminated += $animal['quantity'];
          if (strtolower($animal['source']) === 'owned') $livestockOwned += $animal['quantity'];
        }
        // Count Disseminated and Owned for Poultry
        $poultryDisseminated = 0;
        $poultryOwned = 0;
        foreach ($poultry as $animal) {
          if (strtolower($animal['source']) === 'disseminated') $poultryDisseminated += $animal['quantity'];
          if (strtolower($animal['source']) === 'owned') $poultryOwned += $animal['quantity'];
        }
        ?>
        <div class="row g-3 mb-4 text-center">
          <div class="col-md-6">
            <div class="stats-box d-flex flex-column align-items-center justify-content-center">
              <h5><i class="fas fa-cow me-2"></i>Total Livestock</h5>
              <h3><?php echo $totalLivestock; ?></h3>
              <div style="font-size: 0.9rem; color: #666;">
          Disseminated: <?php echo $livestockDisseminated; ?> | Owned: <?php echo $livestockOwned; ?>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="stats-box d-flex flex-column align-items-center justify-content-center">
              <h5><i class="fas fa-dove me-2"></i>Total Poultry</h5>
              <h3><?php echo $totalPoultry; ?></h3>
              <div style="font-size: 0.9rem; color: #666;">
          Disseminated: <?php echo $poultryDisseminated; ?> | Owned: <?php echo $poultryOwned; ?>
              </div>
            </div>
          </div>
        </div>
        <!-- Search and Filters -->
        <div class="input-group mb-4">
          <input type="text" class="form-control" id="searchInput" placeholder="Search by ID or owners...">
          <button class="btn btn-primary">
            <i class="fas fa-search"></i>
          </button>
          <select class="form-select ms-2" id="speciesFilter" style="max-width: 150px;">
            <option value="">All Species</option>
            <option>Carabao</option>
            <option>Chicken</option>
            <option>Pig</option>
            <option>Cow</option>
          </select>
          <select class="form-select ms-2" id="statusFilter" style="max-width: 150px;">
            <option value="">All Status</option>
            <option>Healthy</option>
            <option>Needs Attention</option>
            <option>Deceased</option>
            <option>Vaccinated</option>
            <option>Not Vaccinated</option>
          </select>
          <select class="form-select ms-2" style="max-width: 150px;">
            <option>All Location</option>
            <option>Brgy. Abuanan</option>
            <option>Brgy. Alianza</option>
            <!-- Other locations -->
          </select>
        </div>
        <!-- Tab Buttons -->
        <div class="tab-buttons mb-3 justify-content-start" style="justify-content: flex-start;">
          <button class="tab-button active" data-tab="livestock">Livestock</button>
          <button class="tab-button" data-tab="poultry">Poultry</button>
        </div>
        <!-- Livestock Table -->
        <div id="livestock-tab" class="tab-content active">
          <table class="table animals-table">
            <thead>
              <tr>
                <th>Client</th>
                <th>Species</th>
                <th>Weight</th>
                <th>Source</th>
                <th>Quantity</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($livestock as $animal): ?>
                <tr class="animal-row" data-species="<?php echo htmlspecialchars($animal['species']); ?>" data-status="<?php echo htmlspecialchars($animal['health_status']); ?>">
                  <td><?php echo htmlspecialchars($animal['client_name']); ?></td>
                  <td><?php echo htmlspecialchars($animal['species']); ?></td>
                  <td><?php echo htmlspecialchars($animal['weight']); ?></td>
                  <td><?php echo htmlspecialchars($animal['source']); ?></td>
                  <td><?php echo htmlspecialchars($animal['quantity']); ?></td>
                  <td>
              <?php
                    $status = strtolower($animal['health_status']);
                    if ($status == 'healthy' || $status == 'vaccinated' || $status == 'alive') {
                        echo '<span class="status status-healthy">Healthy</span>';
                    } elseif ($status == 'needs attention') {
                        echo '<span class="status status-check">Needs Attention</span>';
                    } elseif ($status == 'deceased') {
                        echo '<span class="status" style="background-color: #dc3545;">Deceased</span>';
                    } elseif ($status == 'not vaccinated') {
                        echo '<span class="status" style="background-color: #17a2b8;">Not Vaccinated</span>';
                    } else {
                        echo '<span class="status" style="background-color: #6c757d;">' . ucfirst(htmlspecialchars($animal['health_status'])) . '</span>';
                    }
                  ?>
                </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <!-- Poultry Table -->
        <div id="poultry-tab" class="tab-content">
          <table class="table animals-table">
            <thead>
              <tr>
                <th>Client</th>
                <th>Species</th>
                <th>Source</th>
                <th>Quantity</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($poultry as $animal): ?>
                <tr class="animal-row" data-species="<?php echo htmlspecialchars($animal['species']); ?>" data-status="<?php echo htmlspecialchars($animal['health_status']); ?>">
                  <td><?php echo htmlspecialchars($animal['client_name']); ?></td>
                  <td><?php echo htmlspecialchars($animal['species']); ?></td>
                  <td><?php echo htmlspecialchars($animal['source']); ?></td>
                  <td><?php echo htmlspecialchars($animal['quantity']);?></td>
                  <td>
                    <?php
                      $status = strtolower($animal['health_status']);
                      if ($status == 'healthy' || $status == 'vaccinated' || $status == 'alive') {
                          echo '<span class="status status-healthy">Healthy</span>';
                      } elseif ($status == 'needs attention') {
                          echo '<span class="status status-check">Needs Attention</span>';
                      } elseif ($status == 'deceased') {
                          echo '<span class="status" style="background-color: #dc3545;">Deceased</span>';
                      } elseif ($status == 'not vaccinated') {
                          echo '<span class="status" style="background-color: #17a2b8;">Not Vaccinated</span>';
                      } else {
                          echo '<span class="status" style="background-color: #6c757d;">' . ucfirst(htmlspecialchars($animal['health_status'])) . '</span>';
                      }
                    ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Tab switching functionality
      const tabButtons = document.querySelectorAll('.tab-button');
      const tabContents = document.querySelectorAll('.tab-content');
      
      tabButtons.forEach(button => {
        button.addEventListener('click', function() {
          // Remove active class from all buttons and contents
          tabButtons.forEach(btn => btn.classList.remove('active'));
          tabContents.forEach(content => content.classList.remove('active'));
          
          // Add active class to clicked button
          this.classList.add('active');
          
          // Show corresponding content
          const tabId = this.getAttribute('data-tab') + '-tab';
          document.getElementById(tabId).classList.add('active');
        });
      });
      
      // Search functionality
      const searchInput = document.getElementById('searchInput');
      searchInput.addEventListener('keyup', function() {
        const searchTerm = this.value.toLowerCase();
        const activeTab = document.querySelector('.tab-content.active');
        const rows = activeTab.querySelectorAll('.animal-row');
        
        rows.forEach(row => {
          const text = row.textContent.toLowerCase();
          if(text.includes(searchTerm)) {
            row.style.display = '';
          } else {
            row.style.display = 'none';
          }
        });
      });
      
      // Species filter
      const speciesFilter = document.getElementById('speciesFilter');
      speciesFilter.addEventListener('change', function() {
        filterRows();
      });
      
      // Status filter
      const statusFilter = document.getElementById('statusFilter');
      statusFilter.addEventListener('change', function() {
        filterRows();
      });
      
      function filterRows() {
        const selectedSpecies = speciesFilter.value.toLowerCase();
        const selectedStatus = statusFilter.value.toLowerCase();
        const activeTab = document.querySelector('.tab-content.active');
        const rows = activeTab.querySelectorAll('.animal-row');
        
        rows.forEach(row => {
          const species = row.getAttribute('data-species').toLowerCase();
          const status = row.getAttribute('data-status').toLowerCase();
          
          const speciesMatch = !selectedSpecies || species.includes(selectedSpecies);
          const statusMatch = !selectedStatus || status.includes(selectedStatus);
          
          if(speciesMatch && statusMatch) {
            row.style.display = '';
          } else {
            row.style.display = 'none';
          }
        });
      }
    });
  </script>
</body>
</html>
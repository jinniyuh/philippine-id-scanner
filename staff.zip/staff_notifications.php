<?php
session_start();
include 'includes/conn.php';

// Fetch user information
if (isset($_SESSION["user_id"])) {
    $userId = $_SESSION["user_id"];
    $queryUser = "SELECT * FROM users WHERE user_id = '$userId'";
    $resultUser = mysqli_query($conn, $queryUser);
    if ($resultUser && mysqli_num_rows($resultUser) > 0) {
        $user = mysqli_fetch_assoc($resultUser);
        $staffName = isset($user['name']) ? $user['name'] : 'Staff Name';
    } else {
        $staffName = "Staff Name";
    }
} else {
    $staffName = "Staff Name";
}

// Count pending pharmaceutical requests
$queryPendingRequests = "SELECT COUNT(*) as pending FROM pharmaceutical_requests WHERE status = 'pending'";
$resultPendingRequests = mysqli_query($conn, $queryPendingRequests);
$pendingRequests = 0;
if ($resultPendingRequests && mysqli_num_rows($resultPendingRequests) > 0) {
    $row = mysqli_fetch_assoc($resultPendingRequests);
    $pendingRequests = $row['pending'];
}

// Get the newest pending pharmaceutical request
$queryNewestRequest = "SELECT pr.*, c.name as client_name 
                      FROM pharmaceutical_requests pr 
                      JOIN clients c ON pr.client_id = c.client_id 
                      WHERE pr.status = 'pending' 
                      ORDER BY pr.timestamp DESC LIMIT 1";
$resultNewestRequest = mysqli_query($conn, $queryNewestRequest);
$newestRequest = null;
if ($resultNewestRequest && mysqli_num_rows($resultNewestRequest) > 0) {
    $newestRequest = mysqli_fetch_assoc($resultNewestRequest);
}

// Count unread photo notifications
$queryUnreadPhotos = "SELECT COUNT(*) as unread FROM clients WHERE notif_status = 'unread'";
$resultUnreadPhotos = mysqli_query($conn, $queryUnreadPhotos);
$unreadPhotos = 0;
if ($resultUnreadPhotos && mysqli_num_rows($resultUnreadPhotos) > 0) {
    $row = mysqli_fetch_assoc($resultUnreadPhotos);
    $unreadPhotos = $row['unread'];
}

// Get the newest unread photo notification
$queryNewestPhoto = "SELECT * FROM clients WHERE notif_status = 'unread' ORDER BY timestamp DESC LIMIT 1";
$resultNewestPhoto = mysqli_query($conn, $queryNewestPhoto);
$newestPhoto = null;
if ($resultNewestPhoto && mysqli_num_rows($resultNewestPhoto) > 0) {
    $newestPhoto = mysqli_fetch_assoc($resultNewestPhoto);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Notification Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    /* Main container which holds the sidebar and main content */
    body {
      background-color: #7B8EF3;
      font-family: Arial, sans-serif;
    }
    .container-fluid {
      padding-left: 0;
      padding-right: 0;
      overflow-x: hidden;
    }
    .wrapper {
      display: flex;
      align-items: flex-start;
    }
    /* Main content styling */
    .main-content {
      background: white;
      margin: 20px;
      margin-left: 312px; /* Add margin to offset fixed sidebar */
      padding: 25px;
      border-radius: 10px;
      min-height: 600px;
      height: calc(100vh - 40px);
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    /* Minimize and style scrollbar for main-content */
    .main-content::-webkit-scrollbar {
      width: 8px;
      background: transparent;
    }
    .main-content::-webkit-scrollbar-thumb {
      background: #bdbdbd;
      border-radius: 8px;
    }
    .main-content::-webkit-scrollbar-track {
      background: transparent;
    }
    .main-content {
      scrollbar-width: thin;
      scrollbar-color: #bdbdbd transparent;
    }
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    .page-title h2 {
      margin: 0;
      font-weight: bold;
    }
    .staff-info {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .notification-card {
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      padding: 15px;
      margin-bottom: 15px;
    }
    .notification-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
    }
    .notification-badge {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 15px;
      font-size: 12px;
      color: white;
    }
    .badge-pharmaceuticals {
      background-color: #ff9800;
    }
    .badge-vaccination {
      background-color: #4caf50;
    }
    .badge-photos {
      background-color: #2196f3;
    }
    .badge-urgent {
      background-color: #f44336;
    }
    .badge-health {
      background-color: #9c27b0;
    }
    .notification-time {
      color: #888;
      font-size: 12px;
    }
    .notification-content {
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <div class="container-fluid">
    <!-- Sidebar Section -->
    <div class="wrapper">
      <div class="sidebar">
        <?php include 'includes/staff_sidebar.php'; ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
      <!-- Page Header -->
      <div class="page-header">
        <div class="page-title">
          <h2>Notification Management</h2></div>
        <div class="staff-info">
          <div><?php echo htmlspecialchars($staffName); ?></div>
        </div>
      </div>
      
      <!-- Pharmaceutical Requests Notification -->
      <div class="notification-card">
        <div class="notification-header">
          <div>
            <span class="notification-badge badge-pharmaceuticals">Pharmaceuticals</span>
            <div><?php echo $pendingRequests; ?> Client Request<?php echo $pendingRequests != 1 ? 's' : ''; ?></div>
          </div>
          <div class="notification-time">
            <?php echo isset($newestRequest['timestamp']) ? timeAgo($newestRequest['timestamp']) : '2 hours ago'; ?>
          </div>
        </div>
        <div class="notification-content">
          <?php if ($newestRequest): ?>
            <?php echo htmlspecialchars($newestRequest['client_name']); ?> is requesting for <?php echo htmlspecialchars($newestRequest['quantity']); ?> <?php echo htmlspecialchars($newestRequest['item_name']); ?>.
          <?php endif; ?>
        </div>
      </div>
      
      <!-- Vaccination Notification -->
      <div class="notification-card">
        <div class="notification-header">
          <div>
            <span class="notification-badge badge-vaccination">Vaccination</span>
            <div>Upcoming Vaccinations</div>
          </div>
          <div class="notification-time">1 hours ago</div>
        </div>
        <div class="notification-content">
        </div>
        
      </div>
      
      <!-- Uploaded Photos Notification -->
      <div class="notification-card">
        <div class="notification-header">
          <div>
            <span class="notification-badge badge-photos">Uploaded Photos</span>
            <div><?php echo $unreadPhotos; ?> Client uploaded new photos.</div>
          </div>
          <div class="notification-time">
            <?php echo isset($newestPhoto['timestamp']) ? timeAgo($newestPhoto['timestamp']) : '3 hours ago'; ?>
          </div>
        </div>
        <div class="notification-content">
          <?php if ($newestPhoto): ?>
            <?php echo htmlspecialchars($newestPhoto['name']); ?> uploaded a photos.
          <?php endif; ?>
        </div>
      </div>
      
      <!-- Urgent Health Check Notification -->
      <div class="notification-card">
        <div class="notification-header">
          <div>
            <span class="notification-badge badge-urgent">Urgent</span>
            <span class="notification-badge badge-health">Health Alert</span>
            <div>Urgent Health Check Required</div>
          </div>
          <div class="notification-time">1 hour ago</div>
        </div>
        <div class="notification-content">
          
        </div>
      </div>
      </div>
    </div>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Helper function to format time ago
function timeAgo($timestamp) {
    $time = strtotime($timestamp);
    $time_difference = time() - $time;

    if ($time_difference < 60) {
        return 'just now';
    } elseif ($time_difference < 3600) {
        return round($time_difference / 60) . ' minutes ago';
    } elseif ($time_difference < 86400) {
        return round($time_difference / 3600) . ' hours ago';
    } elseif ($time_difference < 604800) {
        return round($time_difference / 86400) . ' days ago';
    } else {
        return date('F j, Y', $time);
    }
}
?>
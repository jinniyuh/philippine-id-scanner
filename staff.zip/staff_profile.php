<?php
session_start();
include 'includes/conn.php';

// Process form submissions
if(isset($_POST['save_profile'])) {
    $userId = $_SESSION["user_id"];
    $fullName = mysqli_real_escape_string($conn, $_POST['full_name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $contactNumber = mysqli_real_escape_string($conn, $_POST['contact_number']);
    
    $updateQuery = "UPDATE users SET name = '$fullName', username = '$username', contact_number = '$contactNumber' WHERE user_id = '$userId'";
    mysqli_query($conn, $updateQuery);
    
    // Redirect to refresh the page with updated info
    header("Location: staff_profile.php?updated=1");
    exit();
}

// Process password change
if(isset($_POST['update_password'])) {
    $userId = $_SESSION["user_id"];
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    
    // Get current password from database
    $passwordQuery = "SELECT password FROM users WHERE user_id = '$userId'";
    $passwordResult = mysqli_query($conn, $passwordQuery);
    $userData = mysqli_fetch_assoc($passwordResult);
    
    // Verify current password
    if(password_verify($currentPassword, $userData['password']) || $currentPassword === $userData['password']) {
        // Check if new passwords match
        if($newPassword === $confirmPassword) {
            // Hash the new password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            // Update the password
            $updatePasswordQuery = "UPDATE users SET password = '$hashedPassword' WHERE user_id = '$userId'";
            mysqli_query($conn, $updatePasswordQuery);
            
            header("Location: staff_profile.php?password_updated=1");
            exit();
        } else {
            $passwordError = "New passwords do not match";
        }
    } else {
        $passwordError = "Current password is incorrect";
    }
}

// Fetch user information from your users table.
if (isset($_SESSION["user_id"])) {
    $userId = $_SESSION["user_id"];
    $queryUser = "SELECT * FROM users WHERE user_id = '$userId'";
    $resultUser = mysqli_query($conn, $queryUser);
    // At the top of the file, after the query
    if ($resultUser && mysqli_num_rows($resultUser) > 0) {
        $user = mysqli_fetch_assoc($resultUser);
        // Remove the var_dump line
        
        $staffName = isset($user['name']) ? $user['name'] : 'Staff Name';
        $username = isset($user['username']) ? $user['username'] : '';
        $contactNumber = isset($user['contact_number']) ? $user['contact_number'] : '';
        $role = $user['role'] ?? 'Staff';
        $lastLogin = $user['created_at'] ?? 'N/A'; // using created_at since last_login isn't in the DB
        $profilePhoto = $user['profile_photo'] ?? 'assets/default-avatar.png';
    } else {
        $staffName = "Staff Name";
        $username = "";
        $contactNumber = "";
        $role = "Staff";
        $lastLogin = "N/A";
        $profilePhoto = 'assets/default-avatar.png';
    }
} else {
    $staffName = "Staff Name";
    $username = "";
    $contactNumber = "";
    $role = "Staff";
    $lastLogin = "N/A";
    $profilePhoto = 'assets/default-avatar.png';
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Staff Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
    body {
      background-color: #7B8EF3;
      font-family: Arial, sans-serif;
    }
    .container-fluid {
      padding-left: 0;
      padding-right: 0;
      overflow-x: hidden;
    }
    .wrapper {
        display: flex;
        align-items: flex-start;
    }
    /* Main content styling */
    .white-box {
      background: white;
      margin: 20px;
      margin-left: 312px;
      padding: 25px;
      border-radius: 10px;
      min-height: 600px;
      height: calc(100vh - 40px);
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
    }
    .white-box .dashboard-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 25px;
    }
    .white-box .dashboard-header h2 {
      margin: 0;
      font-weight: bold;
  }
    .profile-title {
      text-align: left;
      margin-bottom: 30px;
      margin: 0;
      font-weight: bold;
    }
    .profile-photo {
      width: 130px;
      height: 130px;
      border-radius: 50%;
    }
    /* Profile header inside the main content */
    .profile-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 25px;
      margin: 0;
      font-weight: bold;
    }
    .profile-header h2 {
      margin: 0;
      font-size: 1.8rem;
    }
    .profile-details {
      display: flex;
    }
    .profile-info {
      margin-top: 25px;
      font-size: 0.9rem;
      color: #555;
      margin-left: 20px;  /* Add space between photo and text */
    }
    .profile-info div {
      margin-bottom: 5px;  /* Add space between lines */
    }
    /* Profile content: Two columns if enough width is available */
    .profile-content {
      display: flex;
      gap: 40px;
      flex-wrap: wrap;
      justify-content: center;
      align-items: flex-start;
      width: 100%;
      margin: 0;
    }
    .profile-section {
      flex: 1 1 350px;
      min-width: 320px;
      max-width: 520px;
      background-color: #f9f9f9;
      padding: 28px 24px 24px 24px;
      border-radius: 8px;
      border: 1px solid #e0e0e0;
      box-shadow: 0 1px 4px rgba(0,0,0,0.04);
      margin-bottom: 0;
      display: flex;
      flex-direction: column;
      align-items: stretch;
    }
    .profile-password {
      min-width: 230px;
      background-color: #f9f9f9;
      border-radius: 5px;
      margin-top: 150px;
      height: calc(100% - 214px);
    }
    .profile-section h2 {
      font-size: 1.2rem;
      margin-top: 0;
    }
    .profile-section input {
      width: 100%;
      padding: 10px;
      margin: 15px 0;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
      font-size: 0.9rem;
      height: 40px; 
    }
    .profile-section button {
      background-color: #6a5acd;
      color: #fff;
      border: none;
      padding: 8px 15px;
      border-radius: 5px;
      cursor: pointer;
      height: auto;
    }
    .alert {
      border-radius: 10px;
      margin-bottom: 25px;
      padding: 10px 20px;
    }
    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    .alert-danger {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    </style>
  </head>
<body>
  <div class="container-fluid">
    <div class="wrapper">
      <div class="sidebar">
        <?php include 'includes/staff_sidebar.php'; ?>
      </div>
      <div class="white-box">
        <div class="dashboard-header d-flex justify-content-between align-items-center">
          <h2>Profile</h2>
        </div>
        <?php if(isset($_GET['updated'])): ?>
        <div class="alert alert-success">Profile updated successfully!</div>
        <?php endif; ?>
        <?php if(isset($_GET['password_updated'])): ?>
        <div class="alert alert-success">Password updated successfully!</div>
        <?php endif; ?>
        <?php if(isset($passwordError)): ?>
        <div class="alert alert-danger"><?php echo $passwordError; ?></div>
        <?php endif; ?>
        
        <div class="profile-content mt-4">
          <!-- Personal Information Section -->
          <div class="profile-section" style="max-width: 480px; flex: 1 1 350px;">
            <!-- Profile Details -->
            <div class="profile-details mb-3">
              <img src="<?php echo htmlspecialchars($profilePhoto); ?>" alt="Profile Photo" class="profile-photo">
              <div class="profile-header">
                <div class="profile-info">
                  <div><?php echo htmlspecialchars($staffName); ?></div>
                  <div><?php echo $role; ?></div>
                  <div>Date Created: <?php echo date('M d, Y h:i A', strtotime($lastLogin)); ?></div>
                </div>
              </div>
            </div>
            <h2>Personal Information</h2>
            <form method="POST" action="">
              <input type="text" name="full_name" placeholder="Full Name" value="<?php echo htmlspecialchars($staffName); ?>">
              <input type="text" name="username" placeholder="Username" value="<?php echo htmlspecialchars($username); ?>">
              <input type="text" name="contact_number" placeholder="Contact Number" value="<?php echo htmlspecialchars($contactNumber); ?>">
              <button type="submit" name="save_profile">Save Changes</button>
            </form>
          </div>
          <!-- Change Password Section -->
          <div class="profile-section" style="max-width: 480px; flex: 1 1 350px;">
            <div class="profile-password">
              <h2>Change Password</h2>
              <form method="POST" action="">
                <input type="password" name="current_password" placeholder="Current Password" required>
                <input type="password" name="new_password" placeholder="New Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
                <button type="submit" name="update_password">Update Password</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
    session_start();
    include 'includes/conn.php';

    if (isset($_SESSION["user_id"])) {
        $userId = $_SESSION["user_id"];
        $queryUser = "SELECT * FROM users WHERE user_id = '$userId'";
        $resultUser = mysqli_query($conn, $queryUser);
        if ($resultUser && mysqli_num_rows($resultUser) > 0) {
            $user = mysqli_fetch_assoc($resultUser);
            $staffName = isset($user['name']) ? $user['name'] : 'Staff Name';
            // or you can use the null coalescing operator
            // $staffName = $user['name'] ?? 'Staff Name';
        } else {
            $staffName = "Staff Name";
        }
    } else {
        $staffName = "Staff Name";
    }

    // Add this to your PHP section at the top
    $queryClients = "SELECT COUNT(*) AS total FROM clients";
    $resultClients = mysqli_query($conn, $queryClients);
    $rowClients = mysqli_fetch_assoc($resultClients);
    $totalclients = $rowClients['total'];

    // Livestock Count (for type 'Livestock')
    $queryLivestock = "SELECT SUM(quantity) AS total FROM livestock_poultry WHERE animal_type = 'Livestock'";
    $resultLivestock = mysqli_query($conn, $queryLivestock);
    $rowLivestock = mysqli_fetch_assoc($resultLivestock);
    $livestockCount = $rowLivestock['total'] ?? 0;

    // Poultry Count (sum of quantity for type 'poultry')
    $queryPoultry = "SELECT SUM(quantity) AS total FROM livestock_poultry WHERE animal_type = 'poultry'";
    $resultPoultry = mysqli_query($conn, $queryPoultry);
    $rowPoultry = mysqli_fetch_assoc($resultPoultry);
    $poultryCount = $rowPoultry['total'] ?? 0;

    // Livestock Needing Attention
    $queryLivestockAttention = "SELECT COUNT(*) AS attention FROM livestock_poultry WHERE animal_type = 'Livestock' AND health_status = 'needs attention'";
    $resultLivestockAttention = mysqli_query($conn, $queryLivestockAttention);
    $rowLivestockAttention = mysqli_fetch_assoc($resultLivestockAttention);
    $livestockAttention = $rowLivestockAttention['attention'];

    // Pharmaceuticals Count
    $queryPharm = "SELECT COUNT(*) AS total FROM pharmaceuticals";
    $resultPharm = mysqli_query($conn, $queryPharm);
    $rowPharm = mysqli_fetch_assoc($resultPharm);
    $pharmCount = $rowPharm['total'];

    // Low stock Pharmaceuticals (stock < 10)
    $queryLowStock = "SELECT COUNT(*) AS low_stock FROM pharmaceuticals WHERE stock < 10";
    $resultLowStock = mysqli_query($conn, $queryLowStock);
    $rowLowStock = mysqli_fetch_assoc($resultLowStock);
    $lowStockCount = $rowLowStock['low_stock'];

    // Notification Count (where notif_status = 'Unread')
    $queryNotificationCount = "SELECT COUNT(*) AS notificationCount FROM notifications WHERE status = 'Unread'";
    $resultNotificationCount = mysqli_query($conn, $queryNotificationCount);
    $rowNotificationCount = mysqli_fetch_assoc($resultNotificationCount);
    $notificationCount = $rowNotificationCount['notificationCount'];

    // Transactions Count (where trans_status = 'Pending')
    $queryTransactionsCount = "SELECT COUNT(*) AS transactionCount FROM transactions WHERE status = 'Pending'";
    $resultTransactionsCount = mysqli_query($conn, $queryTransactionsCount);
    $rowTransactionsCount = mysqli_fetch_assoc($resultTransactionsCount);
    $transactionCount = $rowTransactionsCount['transactionCount'];

    // Recent Activities (from the activity_logs table)
    $queryActivities = "SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 3";
    $resultActivities = mysqli_query($conn, $queryActivities);
    $activities = [];
    while ($row = mysqli_fetch_assoc($resultActivities)) {
        $activities[] = $row;
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Staff Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            body {
                background-color: #7B8EF3;
                font-family: Arial, sans-serif;
            }
            
            .container-fluid {
                padding-left: 0;
                padding-right: 0;
                overflow-x: hidden;
            }
            
            /* Main content white box styling */
            .white-box {
                background: white;
                margin: 20px;
                margin-left: 312px; /* Add margin to offset fixed sidebar */
                padding: 0 25px 25px 25px;
                border-radius: 10px;
                min-height: 600px;
                height: calc(100vh - 40px);
                overflow-y: auto;
                flex: 1;
                display: flex;
                flex-direction: column;
            }
            /* Minimize and style scrollbar for white-box */
            .white-box::-webkit-scrollbar {
            width: 8px;
            background: transparent;
            }
            .white-box::-webkit-scrollbar-thumb {
            background: #bdbdbd;
            border-radius: 8px;
            }
            .white-box::-webkit-scrollbar-track {
            background: transparent;
            }
            .white-box {
            scrollbar-width: thin;
            scrollbar-color: #bdbdbd transparent;
            }
            .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: calc(100% + 50px);
            min-height: 80px;
            margin: 0 -25px 0 -25px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            padding: 10px 25px 0 25px;  
            position: sticky;
            top: 0;
            background: white;
            z-index: 10;
            }
            .page-title h2 {
            margin: 0;
            font-weight: bold;
            }
            .staff-info {
            display: flex;
            align-items: center;
            gap: 10px;
            }        
            /* Stats boxes styling */
            .stats-box {
                background: white;
                border-radius: 10px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                height: 150px;
                text-align: center;
                width: 100%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
            }
            
            .stats-box h5 {
                color: #666;
                margin-bottom: 10px;
                display: flex;
                text-align: center;
            }
            
            .stats-box h3 {
                font-size: 2.5rem;
                font-weight: bold;
                margin: 10px 0;
                text-align: center;
            }
            
            /* Search bar styling */
            .input-group .form-control {
                border-radius: 20px 0 0 20px;
                padding: 10px 15px;
            }
            
            .input-group .btn {
                border-radius: 0 20px 20px 0;
                background-color: #8B9FF7;
                border-color: #8B9FF7;
            }
            
            /* Alert styling */
            .alert {
                border-radius: 10px;
                margin-bottom: 25px;
            }
            
            /* Fix notification badge positioning */
            .position-relative {
                display: inline-block;
            }
            
            .position-absolute {
                top: -10px !important;
                right: -10px !important;
            }
            
            .wrapper {
                display: flex;
                align-items: flex-start;
            }
            
            /* Add hover effect for table rows */
            .table tbody tr:hover {
                background-color: #f8f9fa;
                cursor: pointer;
            }
            .updates-section {
                background: #FFF3CD;
                border-radius: 10px;
                padding: 20px;
            }
            
            .updates-section li {
                margin-bottom: 10px;
            }
            
            .updates-section i {
                margin-right: 10px;
            }
            
            .pharmaceuticals-table {
                background: white;
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .table th, .table td {
                padding: 12px;
                border-bottom: 1px solid #dee2e6;
            }
            
            .badge {
                padding: 5px 10px;
                margin-right: 5px;
            }
            
            .white-box .alert {
                margin-bottom: 25px;
                border-radius: 10px;
            }
        </style>
    </head>
    <body>
  <div class="container-fluid">
    <!-- Sidebar Section -->
    <div class="wrapper">
      <div class="sidebar">
        <?php include 'includes/staff_sidebar.php'; ?>
      </div>
      <!-- Main Content -->
      <div class="white-box">
      <!-- Page Header -->
      <div class="page-header">
        <div class="page-title">
<h2>Dashboard</h2></div>
        <div class="staff-info">
<div class="d-flex align-items-center gap-3">
  <i class="fas fa-user-circle"></i>
</div>
<div><?php echo htmlspecialchars($staffName); ?></div>
        </div>
      </div>
                <!-- Stats -->
                <div class="row g-3 mb-4">
                    <!-- Livestock Count -->
                    <div class="col-md-3">
                        <div class="stats-box d-flex flex-column justify-content-center align-items-center">
                            <h5><i class="fas fa-cow me-2 align-items-center"></i>Livestock Count</h5>
                            <h3><?php echo $livestockCount; ?></h3>
                            <small class="text-warning"><?php echo $livestockAttention; ?> need attention</small>
                        </div>
                    </div>
                    <!-- Poultry Count -->
                    <div class="col-md-3">
                        <div class="stats-box d-flex flex-column justify-content-center align-items-center">
                            <h5><i class="fas fa-dove me-2"></i>Poultry Count</h5>
                            <h3><?php echo $poultryCount; ?></h3>
                            <small class="text-success">All healthy</small>
                        </div>
                    </div>
                    <!-- Pharmaceuticals Count -->
                    <div class="col-md-3">
                        <div class="stats-box d-flex flex-column justify-content-center align-items-center">
                            <h5><i class="fas fa-pills me-2"></i>Pharmaceuticals</h5>
                            <h3><?php echo $pharmCount; ?></h3>
                            <small class="text-danger"><?php echo $lowStockCount; ?> low stock</small>
                        </div>
                    </div>
                    <!-- Clients Count -->
                    <div class="col-md-3">
                        <div class="stats-box d-flex flex-column justify-content-center align-items-center">
                            <h5><i class="fas fa-users me-2"></i>Clients</h5>
                            <h3><?php echo $totalclients; ?></h3>
                        </div>
                    </div>
                </div>
                <!-- Important Updates (Notifications & Transactions) -->
                <div class="alert alert-warning">
                    <h5><i class="fas fa-bell me-2"></i>Important Updates</h5>
                    <?php if ($notificationCount > 0): ?>
                        <p class="mb-1">
                            <i class="fas fa-triangle-exclamation text-danger me-2"></i>
                            <?php echo $notificationCount; ?> new notifications
                        </p>
                    <?php else: ?>
                        <p class="mb-1">
                            <i class="fas fa-triangle-exclamation text-danger me-2"></i>
                            No new notifications
                        </p>
                    <?php endif; ?>
                    <?php if ($transactionCount > 0): ?>
                        <p>
                            <i class="fas fa-calendar-check text-info me-2"></i>
                            <?php echo $transactionCount; ?> new transactions
                        </p>
                    <?php else: ?>
                        <p>
                            <i class="fas fa-calendar-check text-info me-2"></i>
                            No new transactions
                        </p>
                    <?php endif; ?>
                </div>
                <!-- Recent Activities -->
                <div class="border p-3">
                    <h5 class="mb-3">Recent Activities</h5>
                    <?php if (!empty($activities)) { ?>
                        <?php foreach ($activities as $activity) { ?>
                            <div class="mb-2">
                                <strong><?php echo htmlspecialchars($activity['action']); ?></strong><br>
                                <small><?php echo date('h:i A', strtotime($activity['timestamp'])); ?></small>
                            </div>
                        <?php } ?>
                    <?php } else { ?>
                        <p>No recent activities found.</p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
<?php
session_start();
include 'includes/conn.php';

// Fetch user information
if (isset($_SESSION["user_id"])) {
    $userId = $_SESSION["user_id"];
    $queryUser = "SELECT * FROM users WHERE user_id = '$userId'";
    $resultUser = mysqli_query($conn, $queryUser);
    if ($resultUser && mysqli_num_rows($resultUser) > 0) {
        $user = mysqli_fetch_assoc($resultUser);
        $staffName = isset($user['name']) ? $user['name'] : 'Staff Name';
    } else {
        $staffName = "Staff Name";
    }
} else {
    $staffName = "Staff Name";
}

// Count total transactions
$queryTotalTransactions = "SELECT COUNT(*) as total FROM transactions";
$resultTotalTransactions = mysqli_query($conn, $queryTotalTransactions);
$totalTransactions = 0; // Default value
if ($resultTotalTransactions && mysqli_num_rows($resultTotalTransactions) > 0) {
    $row = mysqli_fetch_assoc($resultTotalTransactions);
    $totalTransactions = $row['total'];
}

// Count today's transactions
$today = date('Y-m-d');
$queryTodayTransactions = "SELECT COUNT(*) as today FROM transactions WHERE DATE(transaction_date) = '$today'";
$resultTodayTransactions = mysqli_query($conn, $queryTodayTransactions);
$todayTransactions = 0; // Default value
if ($resultTodayTransactions && mysqli_num_rows($resultTodayTransactions) > 0) {
    $row = mysqli_fetch_assoc($resultTodayTransactions);
    $todayTransactions = $row['today'];
}

// Count pending review
$queryPendingReview = "SELECT COUNT(*) as pending FROM transactions WHERE status = 'pending'";
$resultPendingReview = mysqli_query($conn, $queryPendingReview);
$pendingReview = 0; // Default value
if ($resultPendingReview && mysqli_num_rows($resultPendingReview) > 0) {
    $row = mysqli_fetch_assoc($resultPendingReview);
    $pendingReview = $row['pending'];
}

// Fetch transactions with error handling
$sql = "SELECT t.*, c.full_name AS client_name, p.name AS pharma_name
        FROM transactions t
        JOIN clients c ON t.client_id = c.client_id
        JOIN pharmaceuticals p ON t.pharma_id = p.pharma_id
        ORDER BY t.issued_date DESC";

$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transaction Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
            body {
                background-color: #7B8EF3;
                font-family: Arial, sans-serif;
            }
            .container-fluid {
                padding-left: 0;
                padding-right: 0;
                overflow-x: hidden;
            }
            /* Main content white box styling */
            .white-box {
                background: white;
                margin: 20px;
                margin-left: 312px; /* Add margin to offset fixed sidebar */
                padding: 0 25px 25px 25px;
                border-radius: 10px;
                min-height: 600px;
                height: calc(100vh - 40px);
                overflow-y: auto;
                flex: 1;
                display: flex;
                flex-direction: column;
            }
            /* Stats boxes styling */
            .stats-box {
                background: white;
                border-radius: 10px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                height: 150px;
                width: 100%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
            }
            .stats-box h5 {
                color: #666;
                margin-bottom: 10px;
                display: flex;
                align-items: center;
            }
            .stats-box h3 {
                font-size: 2.5rem;
                font-weight: bold;
                margin: 10px 0;
            }
            .stats-box .display-4 {
                font-size: 3rem;
                font-weight: bold;
                margin: 10px 0;
            }    
            /* Search bar styling */
            .input-group .form-control {
                border-radius: 20px 0 0 20px;
                padding: 10px 15px;
            }
            .input-group .btn {
                border-radius: 0 20px 20px 0;
                background-color: #8B9FF7;
                border-color: #8B9FF7;
            }
            /* Alert styling */
            .alert {
                border-radius: 10px;
                margin-bottom: 25px;
            }
            .position-absolute {
                top: -10px !important;
                right: -10px !important;
            }
            .wrapper {
                display: flex;
                align-items: flex-start;
            }
            /* Add hover effect for table rows */
            .table tbody tr:hover {
                background-color: #f8f9fa;
                cursor: pointer;
            }
            .updates-section {
                background: #FFF3CD;
                border-radius: 10px;
                padding: 20px;
            }
            .updates-section li {
                margin-bottom: 10px;
            }
            .updates-section i {
                margin-right: 10px;
            }
            .pharmaceuticals-table {
                background: white;
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .table th, .table td {
                padding: 12px;
                border-bottom: 1px solid #dee2e6;
            }
            .badge {
                padding: 5px 10px;
                margin-right: 5px;
            }
            .badge.active {
                background-color: #28a745;
                color: white;
            }
            /* Header inside the white box */
            .white-box .dashboard-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                width: calc(100% + 50px);
                min-height: 80px;
                margin: 0 -25px 0 -25px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                padding: 10px 25px 0 25px;
                position: sticky;
                top: 0;
                background: white;
                z-index: 10;
            }
            .white-box .dashboard-header h2 {
                margin: 0;
                font-weight: bold;
            }
            .white-box .alert {
                margin-bottom: 25px;
                border-radius: 10px;
            }
            /* Minimize and style scrollbar for white-box */
            .white-box::-webkit-scrollbar {
                width: 8px;
                background: transparent;
            }
            .white-box::-webkit-scrollbar-thumb {
                background: #bdbdbd;
                border-radius: 8px;
            }
            .white-box::-webkit-scrollbar-track {
                background: transparent;
            }
            .white-box {
                scrollbar-width: thin;
                scrollbar-color: #bdbdbd transparent;
            }
            .tab-content {
                display: none !important;
            }
            .tab-content.active {
                display: block !important;
            }
            .tab-buttons {
                display: flex;
                justify-content: center;
                gap: 10px;
                margin-bottom: 15px;
            }
            .tab-button {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 4px;
                padding: 7px 22px;
                cursor: pointer;
                font-weight: 500;
                color: #333;
                transition: background 0.2s, color 0.2s;
            }
            .tab-button.active {
                background-color: #3b5bdb;
                color: #fff;
                border-color: #3b5bdb;
            }
        </style>
</head>
<body>
  <div class="container-fluid">
    <div class="wrapper">
      <div class="sidebar">
        <?php include 'includes/staff_sidebar.php'; ?>
      </div>
      <div class="white-box">
        <div class="dashboard-header d-flex justify-content-between align-items-center">
          <h2>Transaction Management</h2>
          <div class="d-flex align-items-center gap-3">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($staffName); ?></span>
          </div>
        </div>
        <!-- Stats -->
        <div class="row g-3 mb-4">
          <!-- Total Transactions -->
          <div class="col-md-4">
            <div class="stats-box d-flex flex-column justify-content-center align-items-center">
              <h5><i class="fas fa-list me-2 align-items-center"></i>Total Transactions</h5>
              <h3><?php echo number_format($totalTransactions); ?></h3>
            </div>
          </div>
          <!-- Today's Transactions -->
          <div class="col-md-4">
            <div class="stats-box d-flex flex-column justify-content-center align-items-center">
              <h5><i class="fas fa-calendar-day me-2"></i>Today's Transactions</h5>
              <h3><?php echo number_format($todayTransactions); ?></h3>
            </div>
          </div>
          <!-- Pending Review -->
          <div class="col-md-4">
            <div class="stats-box d-flex flex-column justify-content-center align-items-center">
              <h5><i class="fas fa-hourglass-half me-2"></i>Pending Review</h5>
              <h3><?php echo number_format($pendingReview); ?></h3>
            </div>
          </div>
        </div>
        <!-- Alert Box -->
        <?php if ($totalTransactions == 0): ?>
        <div class="alert alert-warning d-flex align-items-center" role="alert">
          <i class="fas fa-exclamation-triangle me-2"></i>
          <div>There are currently no transactions recorded in the system.</div>
        </div>
        <?php endif; ?> 
        <!-- Search and Filters -->
        <div class="input-group mb-4">
          <input type="text" class="form-control" placeholder="Search transactions...">
          <button class="btn btn-primary">
            <i class="fas fa-search"></i>
          </button>
          <select class="form-select ms-2" style="max-width: 150px;">
            <option>All Types</option>
            <option>Stock In</option>
          </select>
          <select class="form-select ms-2" style="max-width: 150px;">
            <option>All Categories</option>
            <option>Vaccines</option>
          </select>
          <input type="date" class="form-control ms-2" style="max-width: 180px;" placeholder="mm/dd/yyyy">
        </div>
        <!-- Transactions Table -->
        <div class="pharmaceuticals-table p-0">
          <table class="table mb-0">
            <thead>
              <tr>
                            <th>#</th>
                            <th>Client Name</th>
                            <th>Medicine Name</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Requested Date</th>
                            <th>Issued Date</th>
                        </tr>
            </thead>
             <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['transaction_id']); ?></td>
                                    <td><?= htmlspecialchars($row['client_name']); ?></td>
                                    <td><?= htmlspecialchars($row['pharma_name']); ?></td>
                                    <td><?= htmlspecialchars($row['quantity']); ?></td>
                                    <td><span class="badge bg-success"><?= htmlspecialchars($row['status']); ?></span></td>
                                    <td><?= htmlspecialchars(date('Y-m-d', strtotime($row['request_date']))); ?></td>
                                    <td><?= htmlspecialchars(date('Y-m-d', strtotime($row['issued_date']))); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center">No transactions found.</td></tr>
                        <?php endif; ?>
                    </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('.form-control[placeholder="Search transactions..."]');
    const searchButton = document.querySelector('.btn.btn-primary');
    const typeFilter = document.querySelectorAll('.form-select')[0];
    const categoryFilter = document.querySelectorAll('.form-select')[1];
    const dateFilter = document.querySelector('input[type="date"]');
    const tableRows = document.querySelectorAll('.table tbody tr');

    // Search function
    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase();
        const typeValue = typeFilter.value;
        const categoryValue = categoryFilter.value;
        const dateValue = dateFilter.value;

        tableRows.forEach(row => {
            // Skip the "No transactions found" row
            if (row.cells.length === 1 && row.cells[0].getAttribute('colspan')) {
                return;
            }

            const transactionId = row.cells[0].textContent.toLowerCase();
            const clientName = row.cells[1].textContent.toLowerCase();
            const medicineName = row.cells[2].textContent.toLowerCase();
            const quantity = row.cells[3].textContent.toLowerCase();
            const status = row.cells[4].textContent.toLowerCase();
            const requestedDate = row.cells[5].textContent;
            const issuedDate = row.cells[6].textContent;

            // Check search term match
            const matchesSearch = searchTerm === '' || 
                                transactionId.includes(searchTerm) || 
                                clientName.includes(searchTerm) || 
                                medicineName.includes(searchTerm) || 
                                quantity.includes(searchTerm) ||
                                status.includes(searchTerm);

            // Check type filter (you can customize this based on your data)
            const matchesType = typeValue === 'All Types' || 
                              (typeValue === 'Stock In' && status.includes('completed')) ||
                              (typeValue === 'Stock Out' && status.includes('pending'));

            // Check category filter (you can customize this based on your data)
            const matchesCategory = categoryValue === 'All Categories' || 
                                  medicineName.includes(categoryValue.toLowerCase());

            // Check date filter
            let matchesDate = true;
            if (dateValue) {
                const filterDate = new Date(dateValue).toISOString().split('T')[0];
                const requestDate = new Date(requestedDate).toISOString().split('T')[0];
                const issueDate = new Date(issuedDate).toISOString().split('T')[0];
                matchesDate = requestDate === filterDate || issueDate === filterDate;
            }

            // Show/hide row based on all filters
            if (matchesSearch && matchesType && matchesCategory && matchesDate) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });

        // Check if any rows are visible
        const visibleRows = Array.from(tableRows).filter(row => 
            row.style.display !== 'none' && 
            !(row.cells.length === 1 && row.cells[0].getAttribute('colspan'))
        );

        // Show/hide "No results found" message
        const noResultsRow = document.querySelector('td[colspan="7"]');
        if (noResultsRow) {
            const noResultsRowParent = noResultsRow.parentElement;
            if (visibleRows.length === 0 && (searchTerm || typeValue !== 'All Types' || categoryValue !== 'All Categories' || dateValue)) {
                noResultsRow.textContent = 'No transactions match your search criteria.';
                noResultsRowParent.style.display = '';
            } else if (visibleRows.length === 0) {
                noResultsRow.textContent = 'No transactions found.';
                noResultsRowParent.style.display = '';
            } else {
                noResultsRowParent.style.display = 'none';
            }
        }
    }

    // Event listeners
    if (searchButton) {
        searchButton.addEventListener('click', function(e) {
            e.preventDefault();
            performSearch();
        });
    }

    if (searchInput) {
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
        searchInput.addEventListener('input', performSearch);
    }

    if (typeFilter) {
        typeFilter.addEventListener('change', performSearch);
    }

    if (categoryFilter) {
        categoryFilter.addEventListener('change', performSearch);
    }

    if (dateFilter) {
        dateFilter.addEventListener('change', performSearch);
    }
});
</script>

</body>
</html>
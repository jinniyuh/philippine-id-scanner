<?php
session_start();
include 'includes/conn.php';

// Fetch user information
if (isset($_SESSION["user_id"])) {
    $userId = $_SESSION["user_id"];
    $queryUser = "SELECT * FROM users WHERE user_id = '$userId'";
    $resultUser = mysqli_query($conn, $queryUser);
    if ($resultUser && mysqli_num_rows($resultUser) > 0) {
        $user = mysqli_fetch_assoc($resultUser);
        $staffName = isset($user['name']) ? $user['name'] : 'Staff Name';
    } else {
        $staffName = "Staff Name";
    }
} else {
    $staffName = "Staff Name";
}

// Count total clients
$queryTotalclients = "SELECT COUNT(*) as total FROM clients";
$resultTotalclients = mysqli_query($conn, $queryTotalclients);
$totalclients = ''; // Default value
if ($resultTotalclients && mysqli_num_rows($resultTotalclients) > 0) {
    $row = mysqli_fetch_assoc($resultTotalclients);
    $totalclients = $row['total'];
}

// Count active clients
$queryActiveclients = "SELECT COUNT(*) as pending FROM clients WHERE status = 'Pending'";
$resultActiveclients = mysqli_query($conn, $queryActiveclients);
$activeclients = ''; // Default value
if ($resultActiveclients && mysqli_num_rows($resultActiveclients) > 0) {
    $row = mysqli_fetch_assoc($resultActiveclients);
    $activeclients = $row['pending'];
}

// Get clients list
// Get clients list with their livestock/poultry data
$queryclients = "SELECT c.*, 
  (SELECT GROUP_CONCAT(DISTINCT animal_type) FROM livestock_poultry WHERE client_id = c.client_id) AS type
  FROM clients c ORDER BY c.client_id";
$resultclients = mysqli_query($conn, $queryclients);
$clients = [];

if ($resultclients && mysqli_num_rows($resultclients) > 0) {
    while ($row = mysqli_fetch_assoc($resultclients)) {
        $clients[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>clients Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            body {
                background-color: #7B8EF3;
                font-family: Arial, sans-serif;
            }

            .container-fluid {
                padding-left: 0;
                padding-right: 0;
                overflow-x: hidden;
            }
            
            /* Main content white box styling */
            .white-box {
                background: white;
                margin: 20px;
                margin-left: 312px; /* Add margin to offset fixed sidebar */
                padding: 0 25px 25px 25px;
                border-radius: 10px;
                min-height: 600px;
                height: calc(100vh - 40px);
                overflow-y: auto;
                flex: 1;
                display: flex;
                flex-direction: column;
            }
            /* Stats boxes styling */
            .stats-box {
                background: white;
                border-radius: 10px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                height: 150px;
                width: 100%;
                text-align: center;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
            }
            .stats-box h5 {
                color: #666;
                margin-bottom: 10px;
                display: flex;
                align-items: center;
            }
            
            .stats-box h3 {
                font-size: 2.5rem;
                font-weight: bold;
                margin: 10px 0;
            }
            .stats-box .display-4 {
                font-size: 3rem;
                font-weight: bold;
                margin: 10px 0;
            }          
            .input-group .btn {
                border-radius: 0 20px 20px 0;
                background-color: #8B9FF7;
                border-color: #8B9FF7;
            }
            /* Alert styling */
            .alert {
                border-radius: 10px;
                margin-bottom: 25px;
            }
            /* Fix notification badge positioning */
            .position-relative {
                display: inline-block;
            }
            .position-absolute {
                top: -10px !important;
                right: -10px !important;
            }
            
            .wrapper {
                display: flex;
                align-items: flex-start;
            }
            
            /* Add hover effect for table rows */
            .table tbody tr:hover {
                background-color: #f8f9fa;
                cursor: pointer;
            }
            .updates-section {
                background: #FFF3CD;
                border-radius: 10px;
                padding: 20px;
            }
            .updates-section li {
                margin-bottom: 10px;
            }
            .updates-section i {
                margin-right: 10px;
            }
            .pharmaceuticals-table {
                background: white;
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .table th, .table td {
                padding: 12px;
                border-bottom: 1px solid #dee2e6;
            }
            .badge {
                padding: 5px 10px;
                margin-right: 5px;
            }
            .badge.active {
                background-color: #28a745;
                color: white;
            }
            /* Header inside the white box */
            .white-box .dashboard-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                width: calc(100% + 50px);
                min-height: 80px;
                margin: 0 -25px 0 -25px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                padding: 10px 25px 0 25px;
                position: sticky;
                top: 0;
                background: white;
                z-index: 10;
            }
            .white-box .dashboard-header h2 {
                margin: 0;
                font-weight: bold;
            }
            
            .white-box .alert {
                margin-bottom: 25px;
                border-radius: 10px;
            }

            /* Minimize and style scrollbar for white-box */
            .white-box::-webkit-scrollbar {
                width: 8px;
                background: transparent;
            }
            .white-box::-webkit-scrollbar-thumb {
                background: #bdbdbd;
                border-radius: 8px;
            }
            .white-box::-webkit-scrollbar-track {
                background: transparent;
            }
            .white-box {
                scrollbar-width: thin;
                scrollbar-color: #bdbdbd transparent;
            }
            .status-inactive {
              background-color: #28a745;
              color: white;
              padding: 3px 8px;
              border-radius: 12px;
              font-size: 12px;
            }
            .status-active {
              background-color: #dc3545; /* red for pending */
              color: white;
              padding: 3px 8px;
              border-radius: 12px;
              font-size: 12.5px;
            }
        </style>
</head>
<body>
  <div class="container-fluid">
    <div class="wrapper">
      <!-- Sidebar Section -->
      <div class="sidebar">
        <?php include 'includes/staff_sidebar.php'; ?>
      </div>
      <!-- Main Content -->
      <div class="white-box">
        <div class="dashboard-header d-flex justify-content-between align-items-center">
          <h2>Clients Management</h2>
          <div class="d-flex align-items-center gap-3">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($staffName); ?></span>
          </div>
        </div>
        <!-- Stats -->
        <div class="row g-3 mb-4">
          <div class="col-md-6">
            <div class="stats-box d-flex flex-column align-items-center justify-content-center ">
              <h5><i class="fas fa-users me-2"></i>Total Clients</h5>
              <h3><?php echo $totalclients; ?></h3>
            </div>
          </div>
          <div class="col-md-6">
            <div class="stats-box d-flex flex-column align-items-center justify-content-center ">
              <h5><i class="fas fa-user-check me-2"></i>Pending Clients</h5>
              <h3><?php echo $activeclients; ?></h3>
            </div>
          </div>
        </div>
        <!-- Search and Filters -->
        <div class="input-group mb-4">
          <input type="text" id="searchInput" class="form-control" placeholder="Search clients...">
          <button class="btn btn-primary" id="searchBtn">
            <i class="fas fa-search"></i>
          </button>
          <select id="statusFilter" class="form-select ms-2" style="max-width: 150px;">
            <option>All Status</option>
            <option>Pending</option>
            <option>Complied</option>
          </select>
          <select id="locationFilter" class="form-select ms-2" style="max-width: 150px;">
            <option>All Location</option>
            <option>Brgy. Ilijan</option>
            <option>Brgy. Malitam</option>
          </select>
          <select id="typeFilter" class="form-select ms-2" style="max-width: 150px;">
            <option>All Types</option>
            <option>Poultry</option>
            <option>Livestock</option>
          </select>

        </div>
        <!-- Clients Table -->
        <table class="table clients-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Contact Number</th>
              <th>Location</th>
              <th>Type</th>
              <th>Registration Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($clients as $client): ?>
              <tr>
                <td><?php echo htmlspecialchars($client['full_name']); ?></td>
                <td><?php echo htmlspecialchars($client['contact_number']); ?></td>
                <td>
                  <a href="#" class="view-btn" data-bs-toggle="modal" data-bs-target="#locationModal<?php echo $client['client_id']; ?>">
                    <i class="fas fa-map-marker-alt"></i> Show Location
                  </a>
                  <!-- Location Modal -->
                  <div class="modal fade" id="locationModal<?php echo $client['client_id']; ?>" tabindex="-1" aria-labelledby="locationLabel<?php echo $client['client_id']; ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="locationLabel<?php echo $client['client_id']; ?>">
                            Location of <?php echo $client['full_name']; ?>
                          </h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                          <div id="map<?php echo $client['client_id']; ?>" style="height: 400px; width: 100%;"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
                <td><?php echo htmlspecialchars($client['type']); ?></td>
                <td><?php echo date('Y-m-d', strtotime($client['created_at'])); ?></td>
                <td>
                  <?php if ($client['status'] == 'Pending'): ?>
                    <span class="status-active">Pending</span>
                  <?php else: ?>
                    <span class="status-inactive">Complied</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  
  <script>
function initMaps() {
  <?php
    // Loop through clients again just to load maps
    $client_result = $conn->query("SELECT client_id, latitude, longitude FROM clients WHERE latitude IS NOT NULL AND longitude IS NOT NULL");
    while ($cl = $client_result->fetch_assoc()):
  ?>
    const map<?php echo $cl['client_id']; ?> = new google.maps.Map(document.getElementById("map<?php echo $cl['client_id']; ?>"), {
      center: { lat: <?php echo floatval($cl['latitude']); ?>, lng: <?php echo floatval($cl['longitude']); ?> },
      zoom: 16
    });

    new google.maps.Marker({
      position: { lat: <?php echo floatval($cl['latitude']); ?>, lng: <?php echo floatval($cl['longitude']); ?> },
      map: map<?php echo $cl['client_id']; ?>,
      title: "Client Location"
    });
  <?php endwhile; ?>
}

// Add this new JavaScript for search functionality
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const statusFilter = document.getElementById('statusFilter');
    const locationFilter = document.getElementById('locationFilter');
    const typeFilter = document.getElementById('typeFilter');
    const tableRows = document.querySelectorAll('.clients-table tbody tr');

    // Search function
    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase();
        const statusValue = statusFilter.value;
        const locationValue = locationFilter.value;
        const typeValue = typeFilter.value;

        tableRows.forEach(row => {
            const name = row.cells[0].textContent.toLowerCase();
            const contact = row.cells[1].textContent.toLowerCase();
            const type = row.cells[3].textContent.toLowerCase();
            const status = row.querySelector('.status-active, .status-inactive').textContent.toLowerCase();

            // Check search term match
            const matchesSearch = searchTerm === '' || 
                                name.includes(searchTerm) || 
                                contact.includes(searchTerm);

            // Check status filter
            const matchesStatus = statusValue === 'All Status' || 
                                status.includes(statusValue.toLowerCase());

            // Check type filter
            const matchesType = typeValue === 'All Types' || 
                              type.includes(typeValue.toLowerCase());

            // Show/hide row based on all filters
            if (matchesSearch && matchesStatus && matchesType) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // Event listeners
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keyup', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    searchInput.addEventListener('input', performSearch);
    statusFilter.addEventListener('change', performSearch);
    locationFilter.addEventListener('change', performSearch);
    typeFilter.addEventListener('change', performSearch);
});
</script>

<!-- Load Google Maps API -->
<script async defer
src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBIwzALxUPNbatRBj3Xi1Uhp0fFzwWNBkE&callback=initMaps">
</script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
</body>
</html>
<?php
session_start();
include 'includes/conn.php';

// Fetch user information
if (isset($_SESSION["user_id"])) {
    $userId = $_SESSION["user_id"];
    $queryUser = "SELECT * FROM users WHERE user_id = '$userId'";
    $resultUser = mysqli_query($conn, $queryUser);
    if ($resultUser && mysqli_num_rows($resultUser) > 0) {
        $user = mysqli_fetch_assoc($resultUser);
        $staffName = isset($user['name']) ? $user['name'] : 'Staff Name';
    } else {
        $staffName = "Staff Name";
    }
} else {
    $staffName = "Staff Name";
}

// Get statistics
// Get total transactions
$totalTransactions = 0;
$query = "SELECT COUNT(*) as total FROM transactions";
$result = mysqli_query($conn, $query);
if ($result && mysqli_num_rows($result) > 0) {
    $totalTransactions = mysqli_fetch_assoc($result)['total'];
}

// Get livestock managed
$livestockManaged = 0;
$query = "SELECT COUNT(*) as total FROM livestock_poultry WHERE animal_type = 'Livestock'";
$result = mysqli_query($conn, $query);
if ($result && mysqli_num_rows($result) > 0) {
    $livestockManaged = mysqli_fetch_assoc($result)['total'];
}

// Get poultry managed
$poultryManaged = 0;
$query = "SELECT COUNT(*) as total FROM livestock_poultry WHERE animal_type = 'Poultry'";
$result = mysqli_query($conn, $query);
if ($result && mysqli_num_rows($result) > 0) {
    $poultryManaged = mysqli_fetch_assoc($result)['total'];
}

// Get medicines dispensed
$medicinesDispensed = 0;
$query = "SELECT COUNT(*) as total FROM transactions WHERE type = 'Pharmaceutical'";
$result = mysqli_query($conn, $query);
if ($result && mysqli_num_rows($result) > 0) {
    $medicinesDispensed = mysqli_fetch_assoc($result)['total'];
}


// Get health monitoring data
$healthMonitoring = [];
$query = $conn->query("SELECT animal_id, animal_type, health_status AS status, last_vaccination AS date 
                       FROM livestock_poultry 
                       ORDER BY last_vaccination DESC 
                       LIMIT 5");

while ($row = $query->fetch_assoc()) {
    $healthMonitoring[] = $row;
}

// Get expiring pharmaceuticals
$expiringPharmaceuticals = [];
$today = date('Y-m-d');

$query = $conn->query("SELECT name AS item, stock, expiry_date 
                       FROM pharmaceuticals 
                       WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY) 
                       ORDER BY expiry_date ASC");

while ($row = $query->fetch_assoc()) {
    $expDate = strtotime($row['expiry_date']);
    $daysLeft = round(($expDate - strtotime($today)) / 86400);

    // Add status label
    if ($daysLeft <= 15) {
        $row['status'] = 'Expiring Soon';
    } elseif ($daysLeft <= 30) {
        $row['status'] = '1 Month Left';
    } else {
        $row['status'] = '2 Months Left';
    }

    $expiringPharmaceuticals[] = $row;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reports & Analytics</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    /* Main container which holds the sidebar and main content */
    body {
      background-color: #7B8EF3;
      font-family: Arial, sans-serif;
    }
    .container-fluid {
      padding-left: 0;
      padding-right: 0;
      overflow-x: hidden;
    }
    .wrapper {
      display: flex;
      align-items: flex-start;
    }
    /* Main content styling */
    .main-content {
      background: white;
      margin: 20px;
      margin-left: 312px;
      padding: 0 25px 25px 25px;
      border-radius: 10px;
      min-height: 600px;
      height: calc(100vh - 40px);
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
    }
    /* Minimize and style scrollbar for main-content */
    .main-content::-webkit-scrollbar {
      width: 8px;
      background: transparent;
    }
    .main-content::-webkit-scrollbar-thumb {
      background: #bdbdbd;
      border-radius: 8px;
    }
    .main-content::-webkit-scrollbar-track {
      background: transparent;
    }
    .main-content {
      scrollbar-width: thin;
      scrollbar-color: #bdbdbd transparent;
    }
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: calc(100% + 50px);
      min-height: 80px;
      margin: 0 -25px 0 -25px;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      padding: 10px 25px 0 25px;
      background: white;
      position: sticky;
      top: 0;
      z-index: 10;
    }
    .page-title h2 {
      margin: 0;
      font-weight: bold;
    }
    .staff-info {
      display: flex;
      align-items: center;
      gap: 7px;
    }
    .stats-box {
        background: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        height: 150px;
        width: 100%;
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
    .stats-box h5 {
        color: #666;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
    }
    .stats-box h3 {
        font-size: 2.5rem;
        font-weight: bold;
        margin: 10px 0;
    }
    .stats-box .display-4 {
        font-size: 3rem;
        font-weight: bold;
        margin: 10px 0;
    }
    .charts-container {
      display: flex;
      gap: 20px;
      margin-bottom: 20px;
    }
    .chart-card {
      flex: 1;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      padding: 20px;
    }
    .chart-title {
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 15px;
    }
    .tables-container {
      display: flex;
      gap: 20px;
      margin-bottom: 20px;
    }
    .table-card {
      flex: 1;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      padding: 20px;
    }
    .table-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
    }
    .table-title {
      font-size: 18px;
      font-weight: bold;
    }
    .view-all {
      color: #6c63ff;
      text-decoration: none;
      font-size: 14px;
    }
    .data-table {
      width: 100%;
      border-collapse: collapse;
    }
    .data-table th {
      background-color: #f5f5f5;
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
      font-size: 14px;
    }
    .data-table td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
      font-size: 14px;
    }
    .status-healthy {
      background-color: #28a745;
      color: white;
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 12px;
    }
    .status-check {
      background-color: #ffc107;
      color: white;
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 12px;
    }
    .status-expiring {
      background-color: #ffc107;
      color: white;
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 12px;
    }
    .status-month {
      background-color: #17a2b8;
      color: white;
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 12px;
    }
  </style>
</head>
<body>
  <div class="container-fluid">
    <!-- Sidebar Section -->
    <div class="wrapper">
      <div class="sidebar">
        <?php include 'includes/staff_sidebar.php'; ?>
      </div>
      <!-- Main Content -->
      <div class="main-content">
      <!-- Page Header -->
      <div class="page-header">
        <div class="page-title">
          <H2>Reports & Analytics</H2></div>
        <div class="staff-info">
          <div class="d-flex align-items-center gap-3">
            <i class="fas fa-user-circle"></i>
          </div>
          <div><?php echo htmlspecialchars($staffName); ?></div>
        </div>
      </div>
      
      <!-- Stats Cards -->
      <div class="row g-3 mb-4">
        <div class="col-md-3">
          <div class="stats-box d-flex flex-column align-items-center justify-content-center">
        <h5><i class="fas fa-capsules me-2"></i>Total Transactions</h5>
        <h3><?php echo $totalTransactions; ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stats-box d-flex flex-column align-items-center justify-content-center">
        <h5><i class="fas fa-hourglass-half me-2"></i>Livestock Managed</h5>
        <h3><?php echo $livestockManaged; ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stats-box d-flex flex-column align-items-center justify-content-center">
        <h5><i class="fas fa-exclamation-circle me-2"></i>Poultry Managed</h5>
        <h3><?php echo $poultryManaged; ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stats-box d-flex flex-column align-items-center justify-content-center">
        <h5><i class="fas fa-list-alt me-2"></i>Medicines Dispensed</h5>
        <h3><?php echo $medicinesDispensed; ?></h3>
          </div>
        </div>
      </div>
      
      <!-- Charts -->
      <!-- <div class="charts-container">
        <div class="chart-card">
          <div class="chart-title">Pharmaceutical Usage Trends</div>
          <canvas id="usageChart"></canvas>
        </div>
        <div class="chart-card">
          <div class="chart-title">Pharmaceutical Distribution</div>
          <canvas id="distributionChart"></canvas>
        </div>
      </div> -->
      
      <!-- Tables -->
      <div class="tables-container">
        <div class="table-card">
          <div class="table-header">
            <div class="table-title">Recent Health Monitoring</div>
            <a href="#" class="view-all">View All</a>
          </div>
          <table class="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Animal ID</th>
                <th>Type</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($healthMonitoring as $record): ?>
                <tr>
                  <td><?php echo date('Y-m-d', strtotime($record['date'])); ?></td>
                  <td><?php echo htmlspecialchars($record['animal_id']); ?></td>
                  <td><?php echo htmlspecialchars($record['animal_type']); ?></td>
                  <td>
                    <?php if ($record['status'] == 'Healthy'): ?>
                      <span class="status-healthy">Healthy</span>
                    <?php else: ?>
                      <span class="status-check">Check Required</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <div class="table-card">
          <div class="table-header">
            <div class="table-title">Expiring Pharmaceuticals</div>
            <a href="#" class="view-all">View All</a>
          </div>
          <table class="data-table">
            <thead>
              <tr>
                <th>Item</th>
                <th>Stock</th>
                <th>Expiry Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($expiringPharmaceuticals as $item): ?>
                <tr>
                  <td><?php echo htmlspecialchars($item['item']); ?></td>
                  <td><?php echo htmlspecialchars($item['stock']); ?></td>
                  <td><?php echo date('Y-m-d', strtotime($item['expiry_date'])); ?></td>
                  <td>
                    <?php if ($item['status'] == 'Expiring Soon'): ?>
                      <span class="status-expiring">Expiring Soon</span>
                    <?php elseif ($item['status'] == '1 Month Left'): ?>
                      <span class="status-month">1 Month Left</span>
                    <?php elseif ($item['status'] == '2 Months Left'): ?>
                      <span class="status-safe">2 Months Left</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>

            </tbody>
          </table>
        </div>
      </div>
      </div>
    </div>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Pharmaceutical Usage Chart
    const usageCtx = document.getElementById('usageChart').getContext('2d');
    const usageChart = new Chart(usageCtx, {
      type: 'bar',
      data: {
        labels: ['Vitamins', 'Antibiotics', 'Supplements', 'Others'],
        datasets: [{
          label: 'Usage This Month',
          data: [55, 42, 35, 20],
          backgroundColor: '#6c63ff',
          borderColor: '#6c63ff',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
    
    // Pharmaceutical Distribution Chart
    const distributionCtx = document.getElementById('distributionChart').getContext('2d');
    const distributionChart = new Chart(distributionCtx, {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Units Distributed',
          data: [52, 65, 82, 83, 58, 45],
          backgroundColor: '#6c63ff',
          borderColor: '#6c63ff',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
    
    // ... existing chart code ...
    
    // Search functionality
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        const searchBtn = document.getElementById('searchBtn');
        const tableFilter = document.getElementById('tableFilter');
        const statusFilter = document.getElementById('statusFilter');
        const healthTable = document.querySelector('.table-card:first-child .data-table tbody');
        const pharmaTable = document.querySelector('.table-card:last-child .data-table tbody');
        const healthTableCard = document.querySelector('.table-card:first-child');
        const pharmaTableCard = document.querySelector('.table-card:last-child');

        function performSearch() {
            const searchTerm = searchInput.value.toLowerCase();
            const tableFilterValue = tableFilter.value;
            const statusFilterValue = statusFilter.value;

            // Show/hide table cards based on table filter
            if (tableFilterValue === 'health') {
                healthTableCard.style.display = 'block';
                pharmaTableCard.style.display = 'none';
            } else if (tableFilterValue === 'pharmaceuticals') {
                healthTableCard.style.display = 'none';
                pharmaTableCard.style.display = 'block';
            } else {
                healthTableCard.style.display = 'block';
                pharmaTableCard.style.display = 'block';
            }

            // Search in health monitoring table
            if (healthTable && (tableFilterValue === 'all' || tableFilterValue === 'health')) {
                const healthRows = healthTable.querySelectorAll('tr');
                healthRows.forEach(row => {
                    const date = row.cells[0].textContent.toLowerCase();
                    const animalId = row.cells[1].textContent.toLowerCase();
                    const type = row.cells[2].textContent.toLowerCase();
                    const status = row.cells[3].textContent.toLowerCase();

                    const matchesSearch = searchTerm === '' || 
                                        date.includes(searchTerm) || 
                                        animalId.includes(searchTerm) || 
                                        type.includes(searchTerm);

                    const matchesStatus = statusFilterValue === 'all' || 
                                        (statusFilterValue === 'healthy' && status.includes('healthy')) ||
                                        (statusFilterValue === 'check' && status.includes('check'));

                    if (matchesSearch && matchesStatus) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }

            // Search in pharmaceuticals table
            if (pharmaTable && (tableFilterValue === 'all' || tableFilterValue === 'pharmaceuticals')) {
                const pharmaRows = pharmaTable.querySelectorAll('tr');
                pharmaRows.forEach(row => {
                    const item = row.cells[0].textContent.toLowerCase();
                    const stock = row.cells[1].textContent.toLowerCase();
                    const expiry = row.cells[2].textContent.toLowerCase();
                    const status = row.cells[3].textContent.toLowerCase();

                    const matchesSearch = searchTerm === '' || 
                                        item.includes(searchTerm) || 
                                        stock.includes(searchTerm) || 
                                        expiry.includes(searchTerm);

                    const matchesStatus = statusFilterValue === 'all' || 
                                        (statusFilterValue === 'expiring' && status.includes('expiring'));

                    if (matchesSearch && matchesStatus) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }
        }

        // Event listeners
        if (searchBtn) searchBtn.addEventListener('click', performSearch);
        if (searchInput) {
            searchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    performSearch();
                }
            });
            searchInput.addEventListener('input', performSearch);
        }
        if (tableFilter) tableFilter.addEventListener('change', performSearch);
        if (statusFilter) statusFilter.addEventListener('change', performSearch);
    });
  </script>
</body>
</html>
